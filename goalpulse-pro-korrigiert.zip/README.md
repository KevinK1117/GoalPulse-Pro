# GoalPulse PRO

Mobile-first Next.js prototype for Vercel with live API-SPORTS fixture fetching.

## Setup

1. `npm install`
2. Copy `.env.example` to `.env.local` and fill in your **direct API-SPORTS** football and hockey keys. Never commit `.env.local`.
3. `npm run dev` and open http://localhost:3000.
4. Push the folder to a private GitHub repository, import it at https://vercel.com/new, and add both API keys under Project → Settings → Environment Variables. Deploy.

## Important limitations

- The app fetches **today's fixtures** from API-SPORTS server-side, but does **not** yet calculate player scoring probabilities. It deliberately shows no invented player percentages or betting combinations.
- Football league IDs: 39, 40, 78, 140, 61, 135, 307, 203, 2, 3. Verify coverage and active seasons for your plan.
- Hockey league discovery searches NHL and DEL. API-SPORTS Hockey's league and season parameters must be checked against the subscribed feed; hockey game retrieval may need a season adjustment for leagues spanning calendar years.
- Fixture status filtering currently retains scheduled and some in-progress matches; implement strict pre-kickoff status handling before using it for recommendations.
- Player analysis needs dedicated historical player statistics, confirmed lineup availability, hockey shot/time-on-ice feeds, calibration/backtesting and a job scheduler/database. Do not interpret this starter as a validated betting model.
- Vercel hosting and a public URL require **your own account and deployment**. No keys are embedded.
